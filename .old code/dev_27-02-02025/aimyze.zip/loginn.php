<?php
//Detect OS First
//include('detect_os.php');

session_start();
$con = mysqli_connect("localhost", "u115629099_project_school", "Project_school_123", "u115629099_project_school");

//$_SESSION['institute'] = 1;
//$_GET['id'] = 1;
// We removed $_SESSION['institute'] 
//echo "Reached 1";
if (isset($_GET['id'])) {
    if (!isset($_GET['id'])) {
        mysqli_close($con);
        //echo "Reached 2";
        header('location: index.php');
    } else {
        $id = mysqli_real_escape_string($con, $_GET['id']);
        session_destroy();
        session_start();
        
        $query = "SELECT * FROM school_db WHERE school_id='" . $id ."'";
        //echo $query;
        $result = mysqli_query($con, $query) or die("School Not Found!");
        if (mysqli_num_rows($result) == 0) {
            mysqli_close($con);
            die("Oops! Please Contact SPOC to report the error");
        } else {
            $row = mysqli_fetch_array($result);
            $_SESSION['db_host'] = $row['host'];
            $_SESSION['db_username'] = $row['username'];
            $_SESSION['db_password'] = $row['password'];
            $_SESSION['db_name'] = $row['db_name'];
            $_SESSION['institute'] = $row['school_id'];

            $query1 = "SELECT * FROM institutes WHERE id=" . $row['id'];
            $result1 = mysqli_query($con, $query1) or die("School Not Found");
            if (mysqli_num_rows($result1) == 0) {
                mysqli_close($con);
                die("Oops! Please Contact SPOC to report the error");
            } else {
                $row1 = mysqli_fetch_array($result1);
                $_SESSION['ins_id'] = $row1['id'];
                $_SESSION['ins_name'] = $row1['name'];
                $_SESSION['ins_tag_line'] = $row1['tag_line'];
                $_SESSION['ins_logo'] = $row1['logo'];
                $_SESSION['ins_email'] = $row1['email'];
                $_SESSION['ins_phone'] = $row1['phone'];
                $_SESSION['ins_address'] = $row1['address'];
                $_SESSION['ins_website'] = $row1['website'];
                $_SESSION['ins_splash'] = $row1['splash'];
                
                setcookie("Institute", $_SESSION['ins_name'], time() + (86400 * 30), "/");
                setcookie("Tag Line", $_SESSION['ins_tag_line'], time() + (86400 * 30), "/");
                

            }
            mysqli_close($con);
            //echo "Reached 3";
            header('location: school/admin/home.php');
        }
    }
} else {
    mysqli_close($con);
    //echo "Reached 4";
    header('location: school/admin/home.php');
}

$urlParts = explode('.', $_SERVER['HTTP_HOST']);
//print_r($urlParts);

?>