<?php
session_start();

$con = mysqli_connect("localhost", "u115629099_project_magpie", "?MCq/nVOoL0", "u115629099_project_magpie");


// Check connection
if (mysqli_connect_errno()) {
  echo "Will Speak Soon!";
  exit();
}

//var_dump($_POST);

if($_SESSION['token'] == $_POST['ser'])
    {
        header('index.php#contact');
    }
    if(isset($_POST['name']) && $_POST['name'] == "")
    {
        die("Please enter your Name");
    }
    else{
        $name = mysqli_real_escape_string($con,$_POST['name']);
    }
    if(isset($_POST['email']) && $_POST['email'] == "")
    {
        die("Please enter your Email");
    }
    else{
        $email = mysqli_real_escape_string($con,$_POST['email']);
    }
    if(isset($_POST['subject']) && $_POST['subject'] == "")
    {
        $subject="";
    }
    else{
        $subject = mysqli_real_escape_string($con,$_POST['subject']);
    }
    if(isset($_POST['message']) && $_POST['message'] == "")
    {
        die("Message is Empty");
    }
    else{
        $message = mysqli_real_escape_string($con,$_POST['message']);
    }
    

    $sql = "INSERT into contact_us(name,email,subject,message) VALUES ('$name','$email','$subject','$message')";
    //echo $sql;
    if(mysqli_query($con,$sql))
    {
        ?>
        <title>Project MagPie</title>
        <script>
        alert("Your Query is Submitted Successfully!");
        location.replace("index.php");
        </script>
        <?php
    }
    ?>
